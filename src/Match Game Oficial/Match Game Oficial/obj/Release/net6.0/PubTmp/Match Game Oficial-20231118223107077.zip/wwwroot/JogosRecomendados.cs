﻿namespace Match_Game_Oficial.wwwroot
{
    public class JogosRecomendados
    {
    }
}
